import java.util.Scanner;


public class ContactList {
   public static void main(String[] args) {
      Scanner scnr = new Scanner(System.in);
      
      System.out.println("Person 1");
      System.out.println("Enter name: ");
      String name = scnr.nextLine();
      System.out.println("Enter phone number: ");
      String number = scnr.nextLine();
      ContactNode c = new ContactNode(name,number);
      System.out.print("You entered: ");
      c.PrintContactNode();
      System.out.println("  ");
      
      System.out.println("Person 2");
      System.out.println("Enter name");
      String name1 = scnr.nextLine();
      System.out.println("Enter number");
      String number1 = scnr.nextLine();
      ContactNode d = new ContactNode(name1,number1);
      System.out.print("You entered: ");
      d.PrintContactNode();
      System.out.println("  ");
      
      System.out.println("Person 3");
      System.out.println("Enter name");
      String name2 = scnr.nextLine();
      System.out.println("Enter number");
      String number2 = scnr.nextLine();
      ContactNode e = new ContactNode(name2,number2);
      System.out.print("You entered: ");
      d.PrintContactNode();
      System.out.println("  ");
      
 
     
     System.out.println("CONTACT LIST");
     
     System.out.println("Name: " + c.getName());
     System.out.println("Phone number: " + c.getNumber());
     System.out.println("  ");
     
     System.out.println("Name: " + d.getName());
     System.out.println("Phone number: " + d.getNumber());
     System.out.println("  ");
     
     System.out.println("Name: " + e.getName());
     System.out.println("Phone number: " + e.getNumber());
     System.out.println("  ");
     
     
     
     //c.getName();
      
      

         
         
   }
}
