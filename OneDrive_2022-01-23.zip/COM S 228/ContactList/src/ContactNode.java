
public class ContactNode{
   private String name;
   private String number;
   private ContactNode next;
   ContactNode(){
	   this.name = null;
	   this.number = null;
	   this.next = null;
   }
   ContactNode(String name , String number){
	   this.name = name;
	      this.number = number;
	      this.next = null;
   }
   
   ContactNode(String name, String number, ContactNode next){
      this.name = name;
      this.number = number;
      this.next = next;
   }
   
   public String getName(){
      return this.name;
   }
   
   public String getNumber(){
      return this.number;
   }
   
   void InsertAfter(ContactNode node) {
          ContactNode tmp = null;
          
          tmp = this.next;
          this.next= node;
          node.next = tmp;
   }
   
   public ContactNode getNext() {
      return this.next;
   }
   
  public void PrintContactNode() {
          System.out.println(this.name + ", " + this.number);
    }
   
}
