import java.util.Arrays;

public class SelectionSort {

	public static int[] Sort(int arr[]) {
		for(int i = 0 ; i < arr.length ; i++) {
			int smallest = i ;
			for (int j = i+1 ; j < arr.length ; j++) {
				if ( arr[j] < arr[smallest]) 
				{
					smallest = j ;
				}
				int temp = arr[i];
				arr[i]=arr[smallest];
				arr[smallest] = temp;
			}
			
			
		}
		return arr;
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= new int[] {7,9,3,18,8};
		System.out.println((Arrays.toString(Sort(arr))));
		
	}
	
}
