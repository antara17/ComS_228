
import java.util.Scanner;
import java.util.ArrayList;
import java.util.StringTokenizer;
 

public class PlantArrayListExample 
{

   // TODO: Define a printArrayList method that prints an ArrayList of plant (or flower) objects
	public static void printArrayList(ArrayList<Plant> arrList)
	{
		for (int i = 0 ; i < arrList.size()  ; i++) 
		{
			arrList.get(i).printInfo();
			
		}
		
		
	}
   
   
   public static void main(String[] args) {
      Scanner scnr = new Scanner(System.in);
      String input;
      
      // TODO: Declare an ArrayList called myGarden that can hold object of type plant
      ArrayList <Plant> myGarden = new ArrayList <Plant> ();

      // TODO: Declare variables - plantName, plantCost, colorOfFlowers, isAnnual
      String plantName = "";
      String plantCost = "";
      String colorofFlower = "";
      boolean isAnnual = true;
      
      
      
      input = scnr.next();
      while(!input.equals("-1")){
         // TODO: Check if input is a plant or flower
         //       Store as a plant object or flower object
         //       Add to the ArrayList myGarden
    	  if(input .equals("flower")) {
      		
      		Flower flower =  new Flower();
      		 
      		plantName = scnr.next();
      		
      		plantCost = scnr.next();
      		
      		if(scnr.next() .equals("false") ) {
      			isAnnual = false;
      		}
      		else {
      			isAnnual = true;
      		}
      		
      		
      		colorofFlower = scnr.next();
      		flower.setPlantName(plantName);
      		flower.setPlantCost(plantCost);
      		(flower).setPlantType(isAnnual);
      		(flower).setColorOfFlowers(colorofFlower);
      	
      		
      		 myGarden.add(flower);
      	Plant p = new Flower();
      		 
      	 }
    	  
    	 if(input .equals ("plant")) {
    		 
    		 Plant plant = new Plant();
    		 
    		 plantName = scnr.next();
    		 plantCost = scnr.next();
    		 
    		 plant.setPlantName(plantName);
    		 plant.setPlantCost(plantCost);
    		 myGarden.add(plant);
    		 
    	
    		 
    	 }
    	
      
         input = scnr.next();
      }
      
      // TODO: Call the method printArrayList to print myGarden
      
      printArrayList(myGarden);
      
   }
}

