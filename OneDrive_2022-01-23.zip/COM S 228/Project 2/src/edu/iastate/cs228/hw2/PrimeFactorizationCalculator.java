package edu.iastate.cs228.hw2;

import java.util.InputMismatchException;
import java.util.Scanner;

public class PrimeFactorizationCalculator {
public static void main(String[] args) {
		
		// How to Use: 
		// Comment out the calculator you don't want to use and run the program
		// Calculator 1: Non-standard calculator format eg. need to specify the operation and values separately
		// Calculator 2: Standard calculator format eg. typing 'x * y' will return the product, typing 'gcd x y' will return gcd of x and y, etc.
		// Just try both if this explanation is confusing
		// Tell me if there is any problems I may have missed
		
		//primeFactorizationCalculator1();
		primeFactorizationCalculator2();
	}
	
	public static void primeFactorizationCalculator2() {
		System.out.println("Prime Factorization Calculator");
		Scanner scan = new Scanner(System.in);
		String userIn;
		long val1;
		long val2;
		PrimeFactorization pf1;
		PrimeFactorization pf2;
		String operator;
		while(true) { //Infinite loop unless user exits
			try {
				System.out.print("Enter equation (type 'help' for help): ");
				userIn = scan.next();
				if(userIn.toLowerCase().equals("help") || userIn.toLowerCase().equals("h")) { //Accepts various keywords to trigger each part
					System.out.println("Prime Factorization Calculator Guide: ");
					System.out.println("Type 2 numbers with * or / between to multiply or divide the 2 numbers");
					System.out.println("Type 'gcd' or 'lcm' followed by 2 numbers to get the gcd or lcm of the 2 numbers");
					System.out.println("Type exit to exit");
				}
				else if(userIn.toLowerCase().equals("exit") || userIn.toLowerCase().equals("quit") || userIn.toLowerCase().equals("q") || userIn.toLowerCase().equals("e") || userIn.toLowerCase().equals("x")) { //Exits the loop
					System.out.println("Exiting the calculator");
					break;
				}
				if(isLong(userIn)) { //If the first value is numeric, then user probably wants multiplication or division
					val1 = Long.parseLong(userIn);
					operator = scan.next(); //Either '*' or '/' is valid
					userIn = scan.next();
					val2 = Long.parseLong(userIn);
					pf1 = new PrimeFactorization(val1);
					pf2 = new PrimeFactorization(val2);
					if(operator.equals("*")){
						pf1.multiply(pf2);
						System.out.println("= " + pf1.value() + " with a factorization of " + pf1.toString());
					}
					else if(operator.equals("/")) {
						if(pf1.dividedBy(pf2)) {
							System.out.println("= " + pf1.value() + " with a factorization of " + pf1.toString());
						}
						else {
							System.out.println(pf1.value() + " cannot be divided by " + pf2.value());
						}
					}
					else { //User did not format expression properly
						System.out.println("Please enter a valid expression");
					}
				}
				else { //If the first value is not numeric, then user probably wants gcd or lcm.
					operator = userIn;
					val1 = scan.nextLong();
					val2 = scan.nextLong();
					pf1 = new PrimeFactorization(val1);
					pf2 = new PrimeFactorization(val2);
					PrimeFactorization pfVal;
					if(operator.toLowerCase().equals("gcd")) {
						pfVal = pf1.gcd(pf2);
						System.out.println("Greatest Common Divisor of " + pf1.value() + " and " + pf2.value() + " is " + pfVal.value() + " with a factorization of " + pfVal.toString());
					}
					else if(operator.toLowerCase().equals("lcm")) {
						pfVal = pf1.lcm(pf2);
						System.out.println("Least Common Multiple of " + pf1.value() + " and " + pf2.value() + " is " + pfVal.value() + " with a factorization of " + pfVal.toString());
					}
					else { //User did not format expression properly
						System.out.println("Please enter a valid expression");
					}
				}
			}
			catch(NumberFormatException e) { //Self explanatory
				System.out.println("Non-numeric value found where numeric value expected");
				scan.nextLine();
			}
			catch(InputMismatchException e) {
				System.out.println("Value exceeds max value of long type");
				scan.nextLine();
			}
		}
		scan.close();
	}
	
	public static boolean isLong(String s) {
		try {
			Long.parseLong(s);
			return true;
		}
		catch(NumberFormatException e) {
			return false;
		}
	}
	
	public static void primeFactorizationCalculator1() {
		System.out.println("Prime Factorization Calculator");
		Scanner scan = new Scanner(System.in);
		String userIn;
		Long userNum;
		boolean valid;
		PrimeFactorization pf = new PrimeFactorization(2);
		while(true) {
			System.out.print("Enter Operation (type 'help' for list of operations): ");
			userIn = scan.next();
			if(userIn.toLowerCase().equals("help") || userIn.toLowerCase().equals("h")) {
				System.out.println("----------------------------List of Operations----------------------------");
				System.out.println("Multiply: Multiply current value by given value");
				System.out.println("Divide: Divides current value by given value");
				System.out.println("GCD: Returns the Greatest Common Divisor of current value and given value");
				System.out.println("LCM: Returns the Least Common Multiple of current value and given value");
				System.out.println("Value: Returns the current value and Prime Factorization of current value");
				System.out.println("Set: Sets current value to given value (current value is 2 by default)");
				System.out.println("Exit: Exits the program");
				System.out.println("--------------------------------------------------------------------------");
			}
			else if(userIn.toLowerCase().equals("set") || userIn.toLowerCase().equals("s")) { //Sets current value
				valid = false;
				while(!valid) { //Loop to check for valid input
					System.out.print("Enter new value: ");
					try {
						userNum = scan.nextLong();
						if(userNum > 1 && userNum <= 9223372036854775807L) {
							pf = new PrimeFactorization(userNum);
							System.out.println("Current value is " + pf.value());
							valid = true;
						}
						else if(userNum < 2){
							System.out.println("Value must be greater than 1");
						}
						else if(userNum > 9223372036854775807L) {
							System.out.println("Value must be less than 9223372036854775807");
						}
					}
					catch(InputMismatchException e) {
						System.out.println("Please enter a value of type long");
						scan.next(); //Needed otherwise a infinite catch loop is created
					}
				}
			}
			else if(userIn.toLowerCase().equals("exit") || userIn.toLowerCase().equals("quit") || userIn.toLowerCase().equals("q") || userIn.toLowerCase().equals("e") || userIn.toLowerCase().equals("x")) { //Exits the loop
				System.out.println("Exiting the calculator");
				break;
			}
			else if(userIn.toLowerCase().equals("multiply") || userIn.toLowerCase().equals("m") || userIn.toLowerCase().equals("*")) { //Multiplication
				valid = false;
				while(!valid) { //Loop to check for valid input
					System.out.print("Enter multiplier: ");
					try {
						userNum = scan.nextLong();
						if(userNum > 1) {
							long orig = pf.value(); //Temporarily holds original value
							pf.multiply(userNum);
							System.out.println(orig + " * " + userNum + " = " + pf.value());
							valid = true;
						}
						else {
							System.out.println("Multiplier must be greater than 1");
						}
					}
					catch(InputMismatchException e) {
						System.out.println("Please enter a value of type long");
						scan.next();
					}
				}
			}
			else if(userIn.toLowerCase().equals("divide") || userIn.toLowerCase().equals("d") || userIn.toLowerCase().equals("/")) { //Division
				valid = false;
				while(!valid) { //Loop to check for valid input
					System.out.print("Enter divisor: ");
					try {
						userNum = scan.nextLong();
						if(userNum > 1) {
							long orig = pf.value(); //Temporarily holds original value
							if(pf.dividedBy(userNum)) {
								System.out.println(orig + " / " + userNum + " = " + pf.value());
							}
							else {
								System.out.println(orig + " cannot be divided by " + userNum);
							}
							
							valid = true;
						}
						else {
							System.out.println("Divisor must be greater than 1");
						}
					}
					catch(InputMismatchException e) {
						System.out.println("Please enter a value of type long");
						scan.next();
					}
				}
			}
			else if(userIn.toLowerCase().equals("gcd")) { //Greatest Common Divisor
				valid = false;
				while(!valid) { //Loop to check for valid input
					System.out.print("Enter second number: ");
					try {
						userNum = scan.nextLong();
						if(userNum > 1) {
							PrimeFactorization newPf = pf.gcd(userNum); //Holds the GCD
							System.out.print("The Greatest Common Divisor of " + pf.value() + " and " + userNum + " is " + newPf.value());
							if(newPf.value() != 1) {
								System.out.println(" with a Factorization of " + newPf.toString());
							}
							else {
								System.out.println("");
							}
							valid = true;
						}
						else {
							System.out.println("Value must be greater than 1");
						}
					}
					catch(InputMismatchException e) {
						System.out.println("Please enter a value of type long");
						scan.next();
					}
				}
			}
			else if(userIn.toLowerCase().equals("lcm")) { //Least Common Multiple
				valid = false;
				while(!valid) {
					System.out.print("Enter second number: ");
					try {
						userNum = scan.nextLong();
						if(userNum > 1) {
							PrimeFactorization newPf = pf.lcm(userNum); //Holds the LCM
							System.out.println("The Greatest Common Divisor of " + pf.value() + " and " + userNum + " is " + newPf.value() + " with a Factorization of " + newPf.toString());
							valid = true;
						}
						else {
							System.out.println("Value must be greater than 1");
						}
					}
					catch(InputMismatchException e) {
						System.out.println("Please enter a value of type long");
						scan.next();
					}
				}
			}
			else if(userIn.toLowerCase().equals("value") || userIn.toLowerCase().equals("v") || userIn.toLowerCase().equals("pf")){ //Outputs current value
				System.out.println("Current value is " + pf.value() + " with a Factorization of " + pf.toString());
			}
		}
		scan.close();
	}

}
