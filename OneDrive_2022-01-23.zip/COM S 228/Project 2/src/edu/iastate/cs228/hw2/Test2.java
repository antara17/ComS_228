package edu.iastate.cs228.hw2;

public class Test2 {

	public static void main(String[] args) {
		PrimeFactorization pf = new PrimeFactorization(405);
		
		System.out.println(pf.toString());
	}

}
