package Project1;

public class Point implements Comparable {
	
	public Point(int [] points) {
		
		
	}

	@Override
	public int compareTo(Object o) {
		
		
		return 0;
	}
	
	
		
	

}
