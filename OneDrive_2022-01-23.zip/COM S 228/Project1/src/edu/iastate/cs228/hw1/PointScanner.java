package edu.iastate.cs228.hw1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;

/**
 * 
 * @author antaras
 *
 */

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;




/**
 * 
 * This class sorts all the points in an array of 2D points to determine a reference point whose x and y 
 * coordinates are respectively the medians of the x and y coordinates of the original points. 
 * 
 * It records the employed sorting algorithm as well as the sorting time for comparison. 
 *
 */
public class PointScanner  
{
	private Point[] points; 
	
	private Point medianCoordinatePoint;  // point whose x and y coordinates are respectively the medians of 
	                                      // the x coordinates and y coordinates of those points in the array points[].
	private Algorithm sortingAlgorithm;    
	
		
	protected long scanTime; 
	
	protected String out;// execution time in nanoseconds. 

	
	
	/**
	 * This constructor accepts an array of points and one of the four sorting algorithms as input. Copy 
	 * the points into the array points[].
	 * 
	 * @param  pts  input array of points 
	 * @throws IllegalArgumentException if pts == null or pts.length == 0.
	 */
	public PointScanner(Point[] pts, Algorithm algo) throws IllegalArgumentException
	{
		if( (pts == null) || (pts.length == 0) ) {
			throw new IllegalArgumentException();
		}
		points = pts;
		sortingAlgorithm = algo;
	}

	
	/**
	 * This constructor reads points from a file. 
	 * 
	 * @param  inputFileName
	 * @throws FileNotFoundException 
	 * @throws InputMismatchException   if the input file contains an odd number of integers
	 */
	protected PointScanner(String inputFileName, Algorithm algo) throws FileNotFoundException, InputMismatchException
	{
		File file = new File(inputFileName);
		
		Scanner scan = new Scanner(file);
		ArrayList<Point> arr = new ArrayList<>();
		int x  = 0;
		int y  = 0;
		int i = 0;
		while(scan.hasNext()) {
			
				x = scan.nextInt();
				
				if(!scan.hasNext()) {
					
					throw new InputMismatchException("File has odd number of points");
				}
			
				y = scan.nextInt();
				
				arr.add(new Point(x,y));
				i++;
				
		sortingAlgorithm = algo;
		}
		
		points = arr.toArray(new Point[] {});
		
        	
     }
	

	
	/**
	 * Carry out two rounds of sorting using the algorithm designated by sortingAlgorithm as follows:  
	 *    
	 *     a) Sort points[] by the x-coordinate to get the median x-coordinate. 
	 *     b) Sort points[] again by the y-coordinate to get the median y-coordinate.
	 *     c) Construct medianCoordinatePoint using the obtained median x- and y-coordinates.     
	 *  
	 * Based on the value of sortingAlgorithm, create an object of SelectionSorter, InsertionSorter, MergeSorter,
	 * or QuickSorter to carry out sorting.       
	 * @param algo
	 * @return
	 */
	public void scan()
	{
		// TODO  
		AbstractSorter aSorter = null; 
		
		// create an object to be referenced by aSorter according to sortingAlgorithm. for each of the two 
		// rounds of sorting, have aSorter do the following: 
		// 
		//     a) call setComparator() with an argument 0 or 1. 
		//
		//     b) call sort(). 		
		// 
		//     c) use a new Point object to store the coordinates of the Median Coordinate Point
		//
		//     d) set the medianCoordinatePoint reference to the object with the correct coordinates.
		//
		//     e) sum up the times spent on the two sorting rounds and set the instance variable scanTime. 
		
if (sortingAlgorithm == Algorithm.SelectionSort) {
			
			
			aSorter = new SelectionSorter(this.points);
			
		} else if (sortingAlgorithm == Algorithm.InsertionSort) {
			
			aSorter = new InsertionSorter(this.points);
			
		} else if (sortingAlgorithm == Algorithm.MergeSort) {
			
			aSorter = new MergeSorter(this.points);
			
		} else {
			
			aSorter = new QuickSorter(this.points);
			
		}
		
		int x = 0; 
		
		int y = 0 ;
		
		long start = System.nanoTime();
		
		aSorter.setComparator(0);
		aSorter.sort();
		x = aSorter.getMedian().getX();
		
		aSorter.setComparator(1);
		aSorter.sort();
		y = aSorter.getMedian().getY();
	
		
		medianCoordinatePoint  = new Point(x,y);
		
		
		long end = System.nanoTime();
			
	
		this.scanTime = end - start ;
		
		
	}
	
	
	/**
	 * Outputs performance statistics in the format: 
	 * 
	 * <sorting algorithm> <size>  <time>
	 * 
	 * For instance, 
	 * 
	 * selection sort   1000	  9200867
	 * 
	 * Use the spacing in the sample run in Section 2 of the project description. 
	 */
	public String stats()
	{ 
		String str = String.format("%-17s %-10d %-10d", this.sortingAlgorithm.toString(), this.points.length, this.scanTime);
		return(str);
	}
	
	
	/**
	 * Write MCP after a call to scan(),  in the format "MCP: (x, y)"   The x and y coordinates of the point are displayed on the same line with exactly one blank space 
	 * in between. 
	 */
	@Override
	public String toString()
	{
		String str = ("MCP: " + "("+ medianCoordinatePoint.getX() +"," + medianCoordinatePoint.getY() + ")");
		return(str);
	
	}
	
	/**
	 *  
	 * This method, called after scanning, writes point data into a file by outputFileName. The format 
	 * of data in the file is the same as printed out from toString().  The file can help you verify 
	 * the full correctness of a sorting result and debug the underlying algorithm. 
	 * @throws IOException 
	 */
	public void writeMCPToFile() throws IOException
	{
		try {
			
			FileWriter file = new FileWriter(new File("outputs.txt"),true);
			
			file.write(toString());
			
			file.close();
			
		} catch (FileNotFoundException exp) {
			
			throw new FileNotFoundException("File not found");
		}
		
	}	

	

		
}
