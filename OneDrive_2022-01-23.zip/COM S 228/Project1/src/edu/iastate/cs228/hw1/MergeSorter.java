package edu.iastate.cs228.hw1;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException; 
import java.lang.IllegalArgumentException; 
import java.util.InputMismatchException;



/**
 *  
 * @author antaras
 *
 */

/**
 * 
 * This class implements the mergesort algorithm.   
 *
 */

public class MergeSorter extends AbstractSorter
{
	// Other private instance variables if you need ... 
	
	/** 
	 * Constructor takes an array of points.  It invokes the superclass constructor, and also 
	 * set the instance variables algorithm in the superclass.
	 *  
	 * @param pts   input array of integers
	 */
	public MergeSorter(Point[] pts) 
	{
		super(pts) ;
		super.algorithm = "Merge Sorter";
	}


	/**
	 * Perform mergesort on the array points[] of the parent class AbstractSorter. 
	 * 
	 */
	@Override 
	public void sort()
	{
		 MergeSortRec(points, 0, points.length-1);
	}

	
	/**
	 * This is a recursive method that carries out mergesort on an array pts[] of points. One 
	 * way is to make copies of the two halves of pts[], recursively call mergeSort on them, 
	 * and merge the two sorted subarrays into pts[].   
	 * 
	 * @param pts	point array 
	 */
	private void merge(Point[] pts, int first, int mid, int last) 
	{
		   int resultSize = last - first + 1;     
		   
		   int size = 0   ;     
		   
		   int i = 0    ;   
		   
		   int j = 0   ;     
		   
		   Point[] result = new Point[resultSize] ;  
		                                         
		   
		    i = first       ;                    
		    j = mid + 1   ;                   
		  
		   while (i <= mid && j <= last) 
		   {
		      if ((pointComparator.compare(points[i], pts[j])< 0)) 
		      {
		         result[size] = pts[i];
		         i++;
		      }
		      else {
		         result[size] = pts[j];
		         j++;
		         
		      }
		      size++;
		   }
		   
		   
		   while (i <= mid) 
		   {
		      result[size] = pts[i];
		      i++;
		      size++;
		   }
		   
		   while (j <= last) 
		   {
		      result[size] = pts[j];
		      j++;
		      size++;
		   }
		
		   for (size = 0; size < resultSize; size++) 
		   {
		      pts[first + size] = result[size];
		   }
	}


		public void MergeSortRec(Point[] pts, int first, int last) 
		{
		   int mid = 0;
		   
		   if (first < last) {
			   
		      mid = (first + last) / 2;  
		      
		      MergeSortRec(pts, first, mid);
		      
		      MergeSortRec(pts, mid + 1, last);
		      
		      merge(pts, first, mid, last);
		   }
		}

}

