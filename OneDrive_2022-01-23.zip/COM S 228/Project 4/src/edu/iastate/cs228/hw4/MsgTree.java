package edu.iastate.cs228.hw4;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * 
 * @author Antara Shah
 *
 */

public class MsgTree {

	public char payloadChar;
	public MsgTree left;
	public MsgTree right;
	public static double bit;
	public static double character;
	public static int counter;
	private static int staticCharIdx = 0 ;

	public static void main(String[] args) throws FileNotFoundException {

		File f = new File("src/monalisa.arch");
		System.out.println("character" + "        " + "code");
		System.out.println("-------------------------------");

		Scanner scan = new Scanner(f);
		if(scan.hasNextLine()) {
			String encodingstr = scan.nextLine();

			String msg = scan.nextLine();
			char n = msg.charAt(0);


			if(n != '1' && n != '0') {
				if(scan.hasNextLine()) {
					String next = scan.nextLine();

					encodingstr += "\n"+ msg;
					MsgTree m = new MsgTree(encodingstr);
					m.decode(m, next);


				}
			}
			else {

				MsgTree m = new MsgTree(encodingstr);
				m.decode(m, msg);


			}
		}
		System.out.println(" ");

		System.out.println("STATISTICS : ");

		double avg = bit/character;
		double space = 0.0 ; 
		double uncompressed = character * 16.0;
		space = (1 - (bit/uncompressed))*100;
		System.out.println( "Avg  bits/char: " + "          " + (String.format("%.1f",avg)));
		System.out.println("Total characters:" + "         "+ counter );
		System.out.println("Space savings:   " + "         " + (String.format("%.1f",space) + "%"));
	}
/**
 * Constructor building the tree from a string
 * @param encodingString
 */


	public MsgTree(String encodingString) {

		char c = 0;
		c = encodingString.charAt(staticCharIdx);


		if( c == '^') 
		{
			if(staticCharIdx < encodingString.length()-1) 
			{
				staticCharIdx++;
				left = new MsgTree(encodingString);

			}
			if(staticCharIdx < encodingString.length()-1) 
			{
				staticCharIdx++;
				right = new MsgTree(encodingString);

			}
		}
		else 
		{
			this.payloadChar = c ;


		}


	}
	/**
	 * Constructor for a single node with null children
	 * @param payloadChar
	 */

	public MsgTree(char payloadChar) {
		this.payloadChar = payloadChar;
		left = null;
		right = null;
	}
/**
 * method to print characters and their binary codes
 * @param root
 * @param code
 */
	public static void printCodes(MsgTree root , String code ) {



		if(root == null) 
		{
			return;
		}

		printCodes(root.left, code + "0");

		printCodes(root.right, code + "1");

		if(root.left==null && root.right==null) {
				bit += code.length();
				character++;

				System.out.println(root.payloadChar + "                 " + code );
			

		}



	}
	/**
	 * prints the decoded message to the console
	 * @param codes
	 * @param msg
	 */

	public void decode(MsgTree codes , String msg) {
		printCodes(codes, "");
		System.out.println(" ");
		System.out.println(" ");

		System.out.println("MESSAGE :");
		MsgTree current = codes ;

		for(int i = 0 ; i < msg.length() ; i++) {
			if(msg.charAt(i) == '0') 
			{

				current = current.left;

			}
			if(current.left == null ) 
			{
				counter++;
				System.out.print(current.payloadChar);
				current = codes ;

			}
			if(msg.charAt(i) == '1') 
			{

				current = current.right;

			}
			if(current.right == null ) 
			{
				counter++;
				System.out.print(current.payloadChar);
				current = codes ;

			}
		}
	}




}

