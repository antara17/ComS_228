
public class BinarySearch {
	public static int Search(int arr[], int num) {
		boolean present = false;
		int n= arr.length;
		int left = 0;
		int right = n-1;
		while ( left <= right ) {
			
			int	mid = (left+right)/2;
			if(arr[mid] == num) {
				//present = true;
				return mid;
			}
			if ( num < arr[mid])	{
				right = mid-1;
				continue;
			}
			else {
				left = mid+1;
				continue;
			}
		}
		
		//return present;
		return -1;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {1,3,5,2,10};
		System.out.println(Search(arr, 5));
		
		
		
		

	}

}
