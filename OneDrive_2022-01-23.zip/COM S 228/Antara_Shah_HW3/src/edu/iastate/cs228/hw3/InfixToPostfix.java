package edu.iastate.cs228.hw3;

import java.io.File;

import java.util.Scanner;
import java.util.Stack;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
/**
 * 
 * @author Antara Shah
 *
 */

public class InfixToPostfix {

	public static String result = "";
	

	public static void main(String[] args) throws IOException {


		File f = new File("src//input.txt");
		FileWriter fileWriter = new FileWriter("src//output.txt");
		try {

			Scanner scan = new Scanner (f);
			while(scan.hasNextLine()) {
				result =  "";
				String str = scan.nextLine();

				fileWriter.append(ToPostfix(str)+ "\n");

			}

			scan.close();

		} catch (FileNotFoundException e) {
			System.out.println("No file found");
			e.printStackTrace();
		}

		fileWriter.close();
	}
	/**
	 * Decides the Precendence of char c . If c = + or - returns 1. 
	 * if c = * or / or % , return 2 
	 * if c = ^ , return 3
	 * if c = ( , return -1
	 * @param Character c that is not null .
	 * @return 0
	 */

	public static int Precendence(char c) {
		if(c == '+' || c == '-') {
			return 1 ;
		}
		else if(c == '*' || c == '/' || c == '%') {
			return 2;
		}
		else if(c == '^') {
			return 3;
		}
		else if(c == '(') {
			return -1 ;
		}
		return 0 ;
	}

	/**
	 * Returns the rank of the string
	 * 
	 * @param str
	 * @return rank
	 */

	public static int Rank(String str) {
		Scanner scan = new Scanner(str);
		String st = "";
		int rank = 0 ;
		while (scan.hasNext()) {

			st = scan.next();

			if(st.equals("+") || st.equals("*") || st.equals("/") ||  st.equals( "%") || st.equals("^") || st.equals("-")) {
				rank -- ;
				continue;

			}
			if(st.equals(")") || st.equals("(")) {
				continue;
			}

			else {

				rank++;
			}

		}
		return rank ;

	}
	
	/**
	 * Converts the given str from infix to postfix 
	 * @param str that is an infix expression
	 * @return result
	 */

	public static String ToPostfix( String str) 
	{
		Stack<Character> stack = new Stack<>();
		Scanner sc = new Scanner(str);
		String r = "";
		String s = "";


		if(Rank(str) >= 1) {

			while (sc.hasNext()) {
				r = sc.next();
				if(sc.hasNext()) {
					s = sc.next();

					if((checkNum(r)== true && checkNum(s)==true) ) {

						return "Error: too many operands" + " (" + s + ")";
					}

					if((checkNum(r)== true && s.equals("("))) {
						return "Error: too many operands" + " (" + sc.next() + ")";
					}
				}
			}

		}		

		if(Rank(str) < 1 && Rank(str)!= 0 ) {

			if(str.length() == 1 ) {
				return "Error: too many operators" + " (" + str.charAt(0) + ")";
			}

			while (sc.hasNext()) {
				r = sc.next();

				if(sc.hasNext()) {

					if(isOperator(r) && isOperator(s = sc.next())) {


						return "Error: too many operators" + " (" + s + ")";
					}

					if(isOperator(r) && s.equals(")") || isOperator(r) && s.equals("(")) {
						return "Error: too many operators" + " (" + r + ")";
					}

				}


			}
		}

		if(Rank(str) == 0)	{

			while (sc.hasNext()) {
				r = sc.next();
				if(sc.hasNext()) {

					if(r.equals("(") && (sc.next().equals(")"))){
						return "Error: no subexpression detected ()";
					}
					if(isOperator(r) && isOperator(s = sc.next())) {


						return "Error: too many operators" + " (" + s + ")";
					}

				}
			}
			if(str.equals("(")) {
				return "Error: no closing parenthesis detected";
			}
			if((!str.equals(")") || !str.equals("(") && numOp(str) == num(str)))  {
				return "Error: too many operators " + "(" + Op(str) + ")" ;
			}
		}


		str = str.replaceAll("\\s", "");

	

		for (int i = 0 ; i < str.length() ; i++) {


			char c = str.charAt(i);



			if(i+1< str.length()) {

				if(c == '(' && str.charAt(i+1) == ')' ) {
					return	"Error: no subexpression detected ()";
				}
			}

			if(Character.isDigit(c)) {

				if( i < str.length()-1 && Character.isDigit(str.charAt(i+1))  ) {
					result += c ;
				}

				else {
					result += c + " ";

				}


			}

			else  if(c == '(') {
				stack.push(c);


			}
			else if(c == ')' && (str.length()== 1) ) {
				return  "Error: no opening parenthesis detected ";
			}
			else if (c == ')' && (str.length()!= 1))
			{

				while(!stack.isEmpty() && stack.peek() != '(' && (checkPren(str)== true) ) {
					result += stack.pop() + " " ;

				}

				stack.pop();


				if(checkPren(str)== false ) {
					return "Error: no opening parenthesis detected ";
				}


			}

			else 
			{
				while (!stack.isEmpty() && Precendence(c) <= Precendence(stack.peek())){

					result += stack.pop()+ " ";
				}
				stack.push(c);
			}

		}
		while (!stack.isEmpty()){

			if(stack.peek() == '(' && numPren(str) == false)

				return "Error: no closing parenthesis detected";

			result += stack.pop()+ " ";
		}

		if(str.length()==1 && str.charAt(0) == '(') {
			return "Error: no closing parenthesis detected";
		}

		return result;
	}

	/**
	 * A boolean method that returns true if "(" is found in the string
	 * @param str, the input string
	 * @return result
	 */

	public static boolean checkPren(String str) {

		str = str.replaceAll("\\s", "");

		boolean result = false;


		for (int i = 0 ; i < str.length() ; i++) {

			char c = str.charAt(i);

			if( c == '(') {
				result =  true ;
			}
		}
		return result;


	}
	/**
	 * returns true if the number of "(" matches the number of ")" else returns false.
	 * @param str
	 * @return result
	 */

	public static boolean numPren(String str) {

		str = str.replaceAll("\\s", "");

		boolean result = false;

		int count1 = 0 ;
		int count2 = 0 ;

		for (int i = 0 ; i < str.length() ; i++) {

			char c = str.charAt(i);

			if( c == '(') {
				count1++;

			}
			if(c == ')') {
				count2++;
			}

		}
		if(count1 == count2) {
			result = true;

		}



		return result;

	}
	/**
	 * Returns true if string str contains an operator(+, *, /, %, ^, -) else returns false.
	 * @param st
	 * @return op
	 */
	public static boolean isOperator(String st) {
		boolean op = false;


		if(st.equals("+") || st.equals("*") || st.equals("/") ||  st.equals( "%") || st.equals("^") || st.equals("-")) {
			op = true ;
		}

		return op ;
	}
	/**
	 * returns the number of opreators(+, *, /, %, ^, -) present in a string str
	 * @param str, input string
	 * @return count
	 */

	public static int numOp(String str) {
		int count = 0 ;
		for (int i = 0 ; i < str.length() ; i++) {
			char c = str.charAt(i);
			if(i < str.length()-1) {
				if(c == '+'|| c == '*' || c == '*' || c == '/' || c== '%' || c == '^' || (c == '-'&& (str.charAt(i+1))== ' ' )) {
					count++;
				}
			}
		}
		return count ;
	}
	/**
	 * Returns the number of niumbers in a string str
	 * @param str
	 * @return s
	 */

	public static int num(String str) {

		str = str.replaceAll("[^0-9]+", " ");
		int  s =str.trim().split(" ").length;
		return(s);
	}
	/**
	 * Returns the last operator from a given  string
	 * @param str
	 * @return r
	 */

	public static char Op(String str) {
		char r = ' ';
		for (int i = 0 ; i < str.length() ; i++) {
			char c = str.charAt(i);


			if(c == '+'|| c == '*' || c == '*' || c == '/' || c== '%' || c == '^' || (c == '-' )) {
				r = c ;

			}
		}
		return r ;
	}
	
	/**
	 * Returns true if the given string str is a  number
	 * @param str
	 * @return is
	 */

	public static boolean checkNum(String str)
	{
		boolean is = false ;


		for(int i = 0 ; i< str.length(); i++) {

			char c = str.charAt(i);

			if(i+1 < str.length()) {
				if(Character.isDigit(c) || (c == '-' && Character.isDigit(str.charAt(i+1))) ) {
					return true;
				}
			}
			else {
				if(Character.isDigit(c)) {
					return true ;
				}
			}
		}
		return false ;


	}


}
